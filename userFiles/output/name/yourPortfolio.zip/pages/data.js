let data = {};
//элементы на странице
//header
export const greeting = document.querySelector('.header__title');
export const job = document.querySelector('.header__description');
export const works = document.querySelector('.header__link');
//about
export const aboutFirst = document.querySelector('.about__paragraph__first')
export const aboutSecond = document.querySelector('.about__paragraph__second')
//skills
export const stack = document.querySelector('.stack');
export const stackDescription = document.querySelector('.stack-description')

export const skillOne = document.querySelector('.skill-one')
export const skillTwo = document.querySelector('.skill-two')
export const skillThree = document.querySelector('.skill-three')

export const toolsOne = document.querySelector('.tools-one')
export const toolsTwo = document.querySelector('.tools-two')
export const toolsThree = document.querySelector('.tools-three')

export const skillDescriptionOne = document.querySelector('.skill-description-one')
export const skillDescriptionTwo = document.querySelector('.skill-description-two')
export const skillDescriptionThree = document.querySelector('.skill-description-three')

//portfolio
export const subtitleOne = document.querySelector('.subtitle-one');
export const paragraphOne = document.querySelector('.paragraph-one');

//footer
export const Dribbble = document.querySelector('.Dribbble');
export const Behance = document.querySelector('.Behance');
export const CodePen = document.querySelector('.CodePen');
export const GitHub = document.querySelector('.GitHub');
export const Medium = document.querySelector('.Medium');
export const LinkedIn = document.querySelector('.LinkedIn');
export const Facebook = document.querySelector('.Facebook');
export const Instagram = document.querySelector('.Instagram');
export const Twitter = document.querySelector('.Twitter');
export const mail = document.querySelector('.mail');
export const tel = document.querySelector('.tel');


